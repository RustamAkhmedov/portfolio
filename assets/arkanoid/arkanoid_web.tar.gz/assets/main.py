import asyncio
from random import randint
import pygame

# Spielfeld-Einstellungen
WIDTH, HEIGHT = 1200, 600
fps = 60

pygame.init()
font = pygame.font.SysFont("Arial", 52)
text = ""
endgame = False
timer_exit = 0
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
bg = pygame.Rect(0, 0, WIDTH, HEIGHT)

# Paddel-Einstellungen
paddle_w = 330
paddle_h = 20
paddle_speed = 20
paddle = pygame.Rect(
    WIDTH / 2 - paddle_w / 2, HEIGHT - paddle_h - 10, paddle_w, paddle_h
)

# Block-Einstellungen
block_w = 100
block_h = 50
block_speed = 15
blocks_hor = 10
blocks_vert = 4

block_list = [
    pygame.Rect(10 + (block_w + 20) * i, 10 + (block_h + 20) * j, block_w, block_h)
    for i in range(blocks_hor)
    for j in range(blocks_vert)
]

# Ball-Einstellungen
ball_radius = 10
ball_speed = 5
ball_rect = int(ball_radius * 2**0.5)
ball = pygame.Rect(randint(40, WIDTH - 40), HEIGHT / 2, 10, 10)

# Ball-Richtung
dx = 1
dy = -1


def detect_collision(dx, dy, ball, block):
    """Bestimmt die neue Richtung des Balls nach einer Kollision"""
    if dx == 1:  # Wenn der Ball sich nach rechts bewegt
        delta_x = ball.right - block.left
    else:
        delta_x = block.right - ball.left
    if dy == 1:
        delta_y = ball.bottom - block.top
    else:
        delta_y = block.bottom - ball.top

    if abs(delta_x - delta_y) < 10:  # Wenn der Ball die Ecke trifft
        dx, dy = -dx, -dy
    elif delta_x > delta_y:
        dy = -dy
    elif delta_x < delta_y:
        dx = -dx
    return dx, dy


def render():
    # Hintergrund, Paddel, Blöcke und Ball zeichnen
    pygame.draw.rect(screen, pygame.Color("black"), bg)
    pygame.draw.rect(screen, pygame.Color("green"), paddle)
    for block in block_list:
        pygame.draw.rect(screen, pygame.Color("red"), block)
    pygame.draw.circle(screen, pygame.Color("blue"), ball.center, ball_radius)


# Hauptfunktion als asynchrone Funktion für WebAssembly
async def main():
    global dx, dy, ball_speed, endgame, text, timer_exit

    running = True
    while running:
        # 1. Event-Schleife
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # 2. Steuerung Paddel
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] and paddle.left > 0:
            paddle.left -= paddle_speed
        elif key[pygame.K_RIGHT] and paddle.right < WIDTH:
            paddle.right += paddle_speed

        # 3. Ballbewegung
        if not endgame:
            ball.x += ball_speed * dx
            ball.y += ball_speed * dy

            # Kollision mit Wänden oder Paddel
            if ball.top < 0 or ball.colliderect(paddle):
                dy = -dy
            if ball.right > WIDTH or ball.left < 0:
                dx = -dx

            # Kollision mit Blöcken
            hit_index = ball.collidelist(block_list)
            if hit_index != -1:
                block = block_list.pop(hit_index)
                dx, dy = detect_collision(dx, dy, ball, block)
                ball_speed += 0.25

            # Siegbedingung
            if not len(block_list):
                text = "WIN"
                endgame = True

            # Niederlagebedingung
            if ball.y > HEIGHT:
                text = "GAME OVER"
                endgame = True

        # 4. Zeichnen & Rendering
        render()

        if endgame:
            screen_text = font.render(text, True, "white")
            pos_text = screen_text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.fill("black")
            screen.blit(screen_text, pos_text)
            timer_exit += 1

            if timer_exit > 100:
                running = False

        pygame.display.flip()

        # Framerate begrenzen
        clock.tick(fps)

        # SEHR WICHTIG: Erlaubt dem Browser im Hintergrund andere Dinge zu tun
        await asyncio.sleep(0)


# Startet die asynchrone Hauptschleife
asyncio.run(main())